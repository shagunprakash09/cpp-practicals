# C++ Practicals

Practical work by **Shagun Prakash (E25B000368)**.

## Practical 01: C++ Fundamentals
Demonstrates data types, `const`, variables, arithmetic/relational/logical operators and `cin`/`cout`.
The program reads a name, roll number and marks in 3 subjects, then prints total, percentage, grade and PASS/FAIL.

### Compile and run
```bash
g++ -std=c++17 -Wall fundamentals.cpp -o fundamentals
./fundamentals
```
Sample input: `Shagun Prakash`, `368`, `78 85.5 69` (see `sample_output.txt`).
