# Library Management System (C++)

Console-based mini project (Practical 12) by **Shagun Prakash (E25B000368)**.
Library staff use it to track books and magazines and see which items are issued.

## Features
- Add books and magazines (unique IDs)
- List all items, search by title word
- Issue and return items (books: 14 days, magazines: 7 days)
- Data saved to `library.csv` on exit and reloaded at start-up
- Errors (unknown ID, already issued, bad number, bad CSV line) are reported without crashing

## Concepts used
| Concept | Where |
|---|---|
| Encapsulation, constructors | `LibraryItem`, `Book`, `Magazine`, `Library` |
| Inheritance + polymorphism | abstract `LibraryItem` with `type()`, `creator()`, `loanDays()` |
| STL | `std::map<int, std::unique_ptr<LibraryItem>>` |
| Exceptions | `LibraryError` -> `ItemNotFound`, `ItemUnavailable` |
| File I/O | `Library::save` / `Library::load` (CSV) |

## Build and run
```bash
g++ -std=c++17 -Wall -Wextra src/main.cpp -o lib
./lib
```
To try with sample data: `cp sample/library.csv .` before running.

## Project layout
```
include/exceptions.h   custom exceptions
include/items.h        LibraryItem, Book, Magazine
include/library.h      Library (map, CSV save/load)
src/main.cpp           menu loop
sample/                sample CSV and console output (2 runs)
```

## UML class diagram
```mermaid
classDiagram
    class runtime_error
    class LibraryError
    class ItemNotFound
    class ItemUnavailable
    runtime_error <|-- LibraryError
    LibraryError <|-- ItemNotFound
    LibraryError <|-- ItemUnavailable

    class LibraryItem {
        <<abstract>>
        #int id
        #string title
        #bool available
        +getId() int
        +getTitle() string
        +isAvailable() bool
        +issue()
        +giveBack()
        +toCsv() string
        +type() string*
        +creator() string*
        +loanDays() int*
    }
    class Book {
        -string author
    }
    class Magazine {
        -string publisher
    }
    class Library {
        -map~int, unique_ptr~LibraryItem~~ items
        -find(id) LibraryItem&
        +add(item)
        +list()
        +search(word)
        +issue(id)
        +giveBack(id)
        +save(file)
        +load(file)
    }
    LibraryItem <|-- Book
    LibraryItem <|-- Magazine
    Library "1" o-- "*" LibraryItem
    Library ..> LibraryError : throws
```
GitHub renders this diagram automatically; export it as `uml.png` from <https://mermaid.live> for your report.
