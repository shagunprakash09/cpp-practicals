#pragma once
#include <string>
#include "exceptions.h"
using namespace std;

// ---------- Class hierarchy (inheritance + polymorphism) ----------
class LibraryItem {
protected:
int id; string title; bool available;
public:
LibraryItem(int i, string t, bool a = true) : id(i), title(move(t)), available(a) {}
virtual ~LibraryItem() = default;
int getId() const { return id; }
const string& getTitle() const { return title; }
bool isAvailable() const { return available; }
void issue() { if (!available) throw ItemUnavailable(title, "is already issued"); available = false; }
void giveBack() { if (available) throw ItemUnavailable(title, "was not issued"); available = true; }
virtual string type() const = 0;
virtual string creator() const = 0;
virtual int loanDays() const = 0;
string toCsv() const { return type() + "," + to_string(id) + "," + title + "," + creator() + "," + (available ? "1" : "0"); }
};
class Book : public LibraryItem {
string author;
public:
Book(int i, string t, string a, bool av = true) : LibraryItem(i, move(t), av), author(move(a)) {}
string type() const override { return "Book"; }
string creator() const override { return author; }
int loanDays() const override { return 14; }
};
class Magazine : public LibraryItem {
string publisher;
public:
Magazine(int i, string t, string p, bool av = true) : LibraryItem(i, move(t), av), publisher(move(p)) {}
string type() const override { return "Magazine"; }
string creator() const override { return publisher; }
int loanDays() const override { return 7; }
};
