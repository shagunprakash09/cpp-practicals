#pragma once
#include <stdexcept>
#include <string>
using namespace std;

// ---------- Exceptions ----------
class LibraryError : public runtime_error {
public: explicit LibraryError(const string& m) : runtime_error(m) {}
};
class ItemNotFound : public LibraryError {
public: explicit ItemNotFound(int id) : LibraryError("No item with ID " + to_string(id)) {}
};
class ItemUnavailable : public LibraryError {
public: ItemUnavailable(const string& t, const string& why) : LibraryError("'" + t + "' " + why) {}
};
